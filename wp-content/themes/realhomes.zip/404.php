<?php
/**
 * 404 Template
 *
 * @since 1.0.0
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/404' );
