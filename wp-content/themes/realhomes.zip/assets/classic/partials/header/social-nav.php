<?php
if ( function_exists( 'ere_social_networks' ) ) {
	ere_social_networks();
}