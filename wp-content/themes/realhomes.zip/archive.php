<?php
/**
 * Archive Template
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/blog/archive' );
