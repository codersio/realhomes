<?php
inspiry_render_property_attachments();