<?php
inspiry_additional_details();