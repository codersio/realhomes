<?php
inspiry_floor_plans();