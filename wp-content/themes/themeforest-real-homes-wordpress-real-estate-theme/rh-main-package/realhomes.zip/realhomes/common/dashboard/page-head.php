<div class="dashboard-page-head">
	<div class="row">
        <div class="col-sm-6">
		    <?php get_template_part( 'common/dashboard/breadcrumbs' ); ?>
        </div>
        <div class="col-sm-6">
	        <?php get_template_part( 'common/dashboard/search' ); ?>
        </div>
	</div>
</div>