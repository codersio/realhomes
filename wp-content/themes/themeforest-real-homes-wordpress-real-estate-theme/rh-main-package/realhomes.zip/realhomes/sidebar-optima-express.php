<?php
/**
 * Sidebar: Optima Express
 *
 * @package realhomes
 */

// only for classic design variation.
if ( 'classic' === INSPIRY_DESIGN_VARIATION ) {
	get_template_part( 'assets/classic/partials/sidebar/optima-express' );
}
