<?php
/**
 * Blog: Archive Template
 *
 * @since      4.0.0
 * @package    realhomes
 * @subpackage ultra
 */

get_template_part( 'assets/ultra/partials/index' );